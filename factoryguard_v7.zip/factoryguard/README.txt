# FactoryGuard AI — Setup Guide
# 3-Phase 400V Motor Simulator + AI Agent

## FOLDER STRUCTURE
factoryguard/
├── simulator/
│   └── motor_simulator.py   ← Real-time motor simulation GUI
├── agent/
│   └── motor_agent.py       ← AI analysis agent (reads CSV + calls Gemini)
└── README.txt               ← This file

## STEP 1 — Install dependencies (run once)
Open PowerShell and run:
    pip install tk

(tkinter is usually included with Python 3.10, so this may not be needed)

## STEP 2 — Get your FREE Gemini API key
1. Go to: https://aistudio.google.com/app/apikey
2. Sign in with your Google account
3. Click "Create API Key"
4. Copy the key (starts with "AIza...")

## STEP 3 — Add your API key
Open:  agent/motor_agent.py
Find:  GEMINI_API_KEY = "YOUR_GEMINI_API_KEY_HERE"
Replace with your actual key, example:
       GEMINI_API_KEY = "AIzaSyXXXXXXXXXXXXXXXXXXXXX"

## STEP 4 — Run the Simulator (Terminal 1)
    cd factoryguard/simulator
    python motor_simulator.py

A dark GUI window opens with sliders and fault buttons.

## STEP 5 — Run the AI Agent (Terminal 2, separate window)
    cd factoryguard/agent
    python motor_agent.py

The agent watches the CSV and calls Gemini every 10 seconds.

## HOW TO USE
- Move the LOAD slider → RPM, Current, Temperature change realistically
- Move the VOLTAGE slider → Simulate voltage supply issues
- Check FAULT INJECTION boxes → Inject real faults:
    * Overtemperature → AI detects thermal issue
    * Bearing Fault   → AI detects vibration anomaly + RPM drop
    * Voltage Drop    → AI detects electrical issue
    * Overcurrent     → AI detects electrical overload
- Watch the AI agent detect and explain each fault in real-time!

## FOR THE HACKATHON DEMO VIDEO
1. Start both windows side by side
2. Begin recording
3. Run at normal load (70%) → AI says HEALTHY
4. Inject Bearing Fault → AI detects WARNING
5. Add Overtemperature → AI escalates to CRITICAL
6. AI recommends shutdown and maintenance steps

## CSV FILE LOCATION
simulator/motor_data.csv  (created automatically, updates every second)
Columns: timestamp, rpm, temperature_c, vibration_mm_s, current_a, voltage_v, power_kw, status
